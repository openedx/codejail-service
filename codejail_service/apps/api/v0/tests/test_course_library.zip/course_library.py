def triangular_number(n):
    return sum(range(n + 1))
